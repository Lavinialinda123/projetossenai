package com.example.appescolamvc.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.appescolamvc.R

class ListagemAluno : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_listagem_aluno)
    }
}